#!/bin/bash

source ./setdb.sh key1db

