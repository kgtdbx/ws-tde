#!/bin/bash

export PATH=$PATH:$ORACLE_HOME/OPatch
