gnome-terminal --execute ./setenv.sh
$shell
