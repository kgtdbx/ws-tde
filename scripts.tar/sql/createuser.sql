create user scott identified by manager42;
grant connect to scott;
grant create table to scott;
grant create index to scott;

